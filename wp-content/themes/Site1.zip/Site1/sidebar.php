<?php
/**
 * Sidebars are currently not supported
 */