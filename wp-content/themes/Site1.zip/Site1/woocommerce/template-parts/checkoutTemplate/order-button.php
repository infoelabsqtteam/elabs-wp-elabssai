<?php echo '<div class="u-align-right u-form-group u-form-submit">
                        <a id="place_order" onclick="submitCheckoutForm();" class="u-btn u-btn-submit u-button-style u-btn-1">' . __('Place order', 'woocommerce') . '</a>
                    </div>'; ?>
