<!-- checkout styles -->

<style>.u-section-1 .u-sheet-1 {
  min-height: 808px;
}
.u-section-1 .u-checkout-1 {
  min-height: 748px;
  margin-bottom: 30px;
  height: auto;
  margin-top: 30px;
}
.u-section-1 .u-table-cell-1 {
  font-weight: 700;
}
.u-section-1 .u-table-cell-3 {
  font-weight: 700;
}
.u-section-1 .u-table-cell-4 {
  font-weight: 700;
}
.u-section-1 .u-btn-1 {
  margin-top: 20px;
}
</style>
