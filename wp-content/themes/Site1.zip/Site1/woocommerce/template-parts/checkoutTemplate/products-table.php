<?php $products_styles = array(
    'trStyle' => '',
    'trClass' => '',
    'td1Style' => '',
    'td1Class' => 'u-align-left u-border-1 u-border-grey-dark-1 u-first-column u-table-cell u-table-cell-1',
    'td2Style' => '',
    'td2Class' => 'u-border-1 u-border-grey-dark-1 u-table-cell'
);