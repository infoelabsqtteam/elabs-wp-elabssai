<?php $checkout_fields_styles = array(
    'checkout_field_class' => 'u-form-group u-form-name',
    'checkout_label_class' => 'u-label',
    'checkout_input_class' => 'u-border-1 u-border-grey-30 u-input u-input-rectangle',
);
