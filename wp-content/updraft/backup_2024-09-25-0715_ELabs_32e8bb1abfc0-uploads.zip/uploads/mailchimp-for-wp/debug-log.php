<?php exit; ?>
[2022-10-07 10:58:21] WARNING: Form 571 > kgau******@gm***.com is already subscribed to the selected list(s)
[2022-10-07 11:00:45] WARNING: Form 571 > kgau******@gm***.com is already subscribed to the selected list(s)
[2022-10-07 11:34:27] WARNING: Form 571 > kgau******@gm***.com is already subscribed to the selected list(s)
[2022-10-07 11:46:27] WARNING: Form 571 > kgau******@gm***.com is already subscribed to the selected list(s)
[2022-10-07 11:46:32] WARNING: Form 571 > kgau******@gm***.com is already subscribed to the selected list(s)
[2022-10-07 11:48:22] WARNING: Form 571 > kgau******@gm***.com is already subscribed to the selected list(s)
[2022-10-07 11:49:16] WARNING: Form 571 > kgau******@gm***.com is already subscribed to the selected list(s)
[2022-10-07 11:50:42] WARNING: Form 571 > kgau******@gm***.com is already subscribed to the selected list(s)
[2022-10-07 11:50:59] WARNING: Form 571 > kgau******@gm***.com is already subscribed to the selected list(s)
[2022-10-07 11:51:16] WARNING: Form 571 > kgau******@gm***.com is already subscribed to the selected list(s)
[2022-10-19 11:33:44] WARNING: Form 571 > kgau******@gm***.com is already subscribed to the selected list(s)
[2022-10-19 11:33:54] ERROR: Form 571 > Mailchimp API error: 400 Bad Request. Invalid Resource. abc@gm***.com looks fake or invalid, please enter a real email address.

Request: 
POST https://us12.api.mailchimp.com/3.0/lists/c35918c5fe/members

{"status":"pending","email_address":"abc@gm***.com","interests":{},"merge_fields":{},"email_type":"html","ip_signup":"2409:4064:220f:1d1c:24f7:b4b0:3774:51df","tags":[]}

Response: 
400 Bad Request
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"Invalid Resource","status":400,"detail":"abc@gm***.com looks fake or invalid, please enter a real email address.","instance":"cc0d830b-c3cb-6d50-cb20-bb6d4bbfe5e3"}
